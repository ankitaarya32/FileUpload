APIs:-
Local API:-
1.GET http://localhost:8080/
Upload .pdf file it will process and upload in H2 database as of now.
2.GET http://localhost:8080/files
List down names of Files
3.GET http://localhost:8080/files/file_name
Replace file_name with actual file name it will download file.

